import { combineReducers } from "redux";
import PostReducers from "./PostReducer";

let reducers = combineReducers({ PostReducers });
export default reducers;
